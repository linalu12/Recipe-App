import React from 'react';

const Footer = () => {
    return (
        <footer>
        <p>&copy; 2024 Recipe App</p>
        </footer>
    );
    };

   export default Footer; 